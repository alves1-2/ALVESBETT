import { useState, useEffect } from 'react'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Volume2, VolumeX, Trophy, TrendingUp } from 'lucide-react'
import { soundManager } from '../../utils/sounds'
import { motion, AnimatePresence } from 'motion/react'

interface RollingBallProps {
  wallet: number
  onBetPlaced: (betAmount: number, won: boolean, winAmount: number) => void
}

export function RollingBall({ wallet, onBetPlaced }: RollingBallProps) {
  const [betAmount, setBetAmount] = useState('')
  const [rolling, setRolling] = useState(false)
  const [ballPosition, setBallPosition] = useState(4)
  const [result, setResult] = useState<{ position: number; multiplier: number; won: boolean } | null>(null)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [recentResults, setRecentResults] = useState<number[]>([2.0, 0.5, 1.2, 0.3, 0.7])

  // Mountain stairs with multipliers - mostly losing positions
  const stairs = [
    { multiplier: 0.1, color: 'bg-gradient-to-t from-red-600 to-red-500' },
    { multiplier: 0.2, color: 'bg-gradient-to-t from-red-500 to-red-400' },
    { multiplier: 0.3, color: 'bg-gradient-to-t from-orange-600 to-orange-500' },
    { multiplier: 0.5, color: 'bg-gradient-to-t from-yellow-600 to-yellow-500' },
    { multiplier: 1.2, color: 'bg-gradient-to-t from-green-500 to-green-400' },
    { multiplier: 2.0, color: 'bg-gradient-to-t from-green-600 to-green-500' },
    { multiplier: 0.7, color: 'bg-gradient-to-t from-orange-500 to-orange-400' },
    { multiplier: 0.4, color: 'bg-gradient-to-t from-red-500 to-red-400' },
    { multiplier: 0.1, color: 'bg-gradient-to-t from-red-600 to-red-500' },
  ]

  useEffect(() => {
    soundManager.setEnabled(soundEnabled)
  }, [soundEnabled])

  const quickBet = (multiplier: number) => {
    const currentBet = parseFloat(betAmount) || 100
    const newBet = multiplier === 0 ? wallet : currentBet * multiplier
    setBetAmount(Math.min(newBet, wallet).toFixed(0))
    soundManager.buttonClick()
  }

  const roll = () => {
    const bet = parseFloat(betAmount)
    if (!bet || bet > wallet || bet <= 0) {
      soundManager.error()
      return
    }

    soundManager.betPlaced()
    setRolling(true)
    setResult(null)

    // Weighted random - 70% chance of losing position (0.1-0.7)
    const random = Math.random()
    let position: number
    if (random < 0.7) {
      // Losing positions (indices with multiplier < 1.0)
      const losingIndices = [0, 1, 2, 3, 6, 7, 8]
      position = losingIndices[Math.floor(Math.random() * losingIndices.length)]
    } else {
      // Winning positions
      const winningIndices = [4, 5]
      position = winningIndices[Math.floor(Math.random() * winningIndices.length)]
    }

    // Animate ball rolling with sound
    let current = 0
    const interval = setInterval(() => {
      current = (current + 1) % stairs.length
      setBallPosition(current)
      soundManager.ballRoll()
    }, 150)

    setTimeout(() => {
      clearInterval(interval)
      setBallPosition(position)
      soundManager.ballLand()
      
      const multiplier = stairs[position].multiplier
      const winAmount = bet * multiplier
      const won = multiplier >= 1.0

      setTimeout(() => {
        if (won) {
          soundManager.spinWin()
        } else {
          soundManager.spinLose()
        }
        setResult({ position, multiplier, won })
        onBetPlaced(bet, won, winAmount)
        setRolling(false)
        setRecentResults(prev => [multiplier, ...prev.slice(0, 4)])
      }, 300)
    }, 2500)
  }

  return (
    <div className="space-y-6">
      {/* Stats Header */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gradient-to-br from-purple-900/40 to-purple-800/40 backdrop-blur-sm rounded-xl p-4 border border-purple-500/30">
          <div className="flex items-center gap-2 text-purple-300 text-sm mb-2">
            <Trophy className="w-4 h-4" />
            <span>Top Multiplier</span>
          </div>
          <div className="text-white text-2xl">2.0x</div>
        </div>
        
        <div className="bg-gradient-to-br from-blue-900/40 to-blue-800/40 backdrop-blur-sm rounded-xl p-4 border border-blue-500/30">
          <div className="flex items-center gap-2 text-blue-300 text-sm mb-2">
            <TrendingUp className="w-4 h-4" />
            <span>Recent Results</span>
          </div>
          <div className="flex gap-1 flex-wrap">
            {recentResults.map((mult, i) => (
              <span
                key={i}
                className={`text-xs px-2 py-1 rounded ${
                  mult >= 1.0 ? 'bg-green-500/30 text-green-300' : 'bg-red-500/30 text-red-300'
                }`}
              >
                {mult}x
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Game Area */}
      <div className="bg-gradient-to-br from-purple-900/30 to-black/50 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/30">
        <div className="relative h-96 bg-gradient-to-b from-blue-900/20 via-purple-900/20 to-black/30 rounded-xl border-2 border-purple-500/50 p-6 overflow-hidden">
          {/* Background effects */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_#a855f7_0%,_transparent_50%)]" />
          </div>

          <div className="flex items-center justify-between mb-4">
            <h3 className="text-purple-200 text-lg">Mountain Stairs</h3>
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="text-purple-300 hover:text-purple-100 transition-colors"
            >
              {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
          </div>
          
          <div className="flex justify-center items-end h-full gap-2 relative">
            {stairs.map((stair, i) => {
              const height = i === 4 || i === 5 ? 180 : (i % 3 + 1) * 60
              return (
                <div key={i} className="flex flex-col items-center gap-3 relative">
                  {/* Ball */}
                  <AnimatePresence>
                    {ballPosition === i && (
                      <motion.div
                        initial={{ scale: 0, y: -50 }}
                        animate={{ 
                          scale: 1, 
                          y: 0,
                          rotate: rolling ? 360 : 0
                        }}
                        exit={{ scale: 0 }}
                        transition={{ 
                          type: "spring", 
                          stiffness: 260,
                          damping: 20,
                          rotate: { duration: 0.5, repeat: rolling ? Infinity : 0 }
                        }}
                        className="w-10 h-10 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 border-3 border-yellow-200 shadow-[0_0_25px_rgba(250,204,21,0.9)] flex items-center justify-center"
                      >
                        <div className="w-3 h-3 rounded-full bg-white/50" />
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Stair */}
                  <motion.div 
                    animate={{
                      scale: ballPosition === i ? 1.05 : 1,
                      boxShadow: ballPosition === i 
                        ? '0 0 30px rgba(168, 85, 247, 0.6)' 
                        : '0 0 0px rgba(168, 85, 247, 0)'
                    }}
                    className={`w-20 ${stair.color} rounded-t-xl border-2 border-white/30 flex items-center justify-center relative overflow-hidden shadow-lg`}
                    style={{ 
                      height: `${height}px`,
                      transition: 'all 0.3s'
                    }}
                  >
                    {/* Shine effect */}
                    <div className="absolute inset-0 bg-gradient-to-t from-transparent via-white/10 to-transparent" />
                    
                    {/* Multiplier */}
                    <span className="text-white font-bold text-lg drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] z-10">
                      {stair.multiplier}x
                    </span>

                    {/* Win indicator */}
                    {(i === 4 || i === 5) && (
                      <div className="absolute top-2 right-2">
                        <Trophy className="w-4 h-4 text-yellow-300" />
                      </div>
                    )}
                  </motion.div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Result Display */}
        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: -20 }}
              className={`mt-6 p-6 rounded-xl border-2 text-center ${
                result.won 
                  ? 'border-green-500 bg-gradient-to-br from-green-500/20 to-green-600/20' 
                  : 'border-red-500 bg-gradient-to-br from-red-500/20 to-red-600/20'
              }`}
            >
              <div className="text-5xl mb-2">{result.won ? '🎉' : '💔'}</div>
              <p className="text-white text-2xl mb-2">
                {result.won ? 'Winner!' : 'Better Luck Next Time'}
              </p>
              <p className="text-white text-xl">
                Multiplier: <span className={`${result.won ? 'text-green-400' : 'text-red-400'} font-bold`}>{result.multiplier}x</span>
              </p>
              {result.won && (
                <p className="text-green-300 mt-2 text-lg">
                  Won: {(parseFloat(betAmount) * result.multiplier).toFixed(0)} FRW
                </p>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Betting Controls */}
      <div className="bg-gradient-to-br from-purple-900/30 to-black/50 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/30">
        <div className="space-y-4 max-w-md mx-auto">
          <div className="space-y-2">
            <label className="text-purple-200">Bet Amount (FRW)</label>
            <Input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(e.target.value)}
              placeholder="Enter bet amount"
              disabled={rolling}
              className="bg-purple-900/30 border-purple-500/50 text-white text-lg h-12"
            />
          </div>

          {/* Quick Bet Buttons */}
          <div className="grid grid-cols-4 gap-2">
            <Button
              onClick={() => quickBet(0.5)}
              disabled={rolling}
              variant="outline"
              className="bg-purple-900/20 border-purple-500/50 text-purple-200 hover:bg-purple-800/40"
            >
              1/2
            </Button>
            <Button
              onClick={() => quickBet(2)}
              disabled={rolling}
              variant="outline"
              className="bg-purple-900/20 border-purple-500/50 text-purple-200 hover:bg-purple-800/40"
            >
              2x
            </Button>
            <Button
              onClick={() => quickBet(0)}
              disabled={rolling}
              variant="outline"
              className="bg-purple-900/20 border-purple-500/50 text-purple-200 hover:bg-purple-800/40"
            >
              Max
            </Button>
            <Button
              onClick={() => setBetAmount('')}
              disabled={rolling}
              variant="outline"
              className="bg-purple-900/20 border-purple-500/50 text-purple-200 hover:bg-purple-800/40"
            >
              Clear
            </Button>
          </div>

          <Button
            onClick={roll}
            disabled={rolling || !betAmount || parseFloat(betAmount) > wallet || parseFloat(betAmount) <= 0}
            className="w-full bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-700 hover:via-pink-700 hover:to-blue-700 h-14 text-lg shadow-[0_0_20px_rgba(168,85,247,0.5)] hover:shadow-[0_0_30px_rgba(168,85,247,0.7)] transition-all"
          >
            {rolling ? (
              <span className="flex items-center gap-2">
                <span className="animate-spin">🎯</span> Rolling...
              </span>
            ) : (
              '🎲 ROLL BALL'
            )}
          </Button>
        </div>
      </div>

      {/* Game Info */}
      <div className="bg-gradient-to-r from-purple-900/20 via-blue-900/20 to-purple-900/20 p-4 rounded-xl border border-purple-500/30 text-center backdrop-blur-sm">
        <p className="text-purple-300 text-sm">
          💡 The ball will land on one of the stairs. Higher multipliers are at the center! Win up to 2.0x your bet!
        </p>
      </div>
    </div>
  )
}
